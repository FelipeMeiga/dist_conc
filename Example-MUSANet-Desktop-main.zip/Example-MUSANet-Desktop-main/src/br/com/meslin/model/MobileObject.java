package br.com.meslin.model;

public interface MobileObject {
	public double getLatitude();
	public void setLatitude(double latitude);
	public double getLongitude();
	public void setLongitude(double longitude);
}
